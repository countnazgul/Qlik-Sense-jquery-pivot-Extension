Qlik Sense jquery.pivot Extension
=================================

The extension will use [jquery.pivot](https://github.com/janusschmidt/jquery.pivot) in Qlik Sense
